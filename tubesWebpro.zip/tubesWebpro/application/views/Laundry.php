<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buih Bersih Laundry</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

    <!-- css -->
    <link rel="stylesheet" href="css/style.css">

    <!-- bootstrap jquery -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
    
    <!-- boxslider -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
    <!-- Datatables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">

</head>
<div>
    <nav class="navbar navbar-light bg-light">
        <img src="assets/logonav.jpg" class="navbar-brand" width = "80" >
        <form class="form-inline">
            <a class="nav-link" href="#header">Home <span class="sr-only"></span></a>
          <a href="Login.html" class="btn btn-outline-primary my-2 my-sm-0">Login</a>
        </form>
    </nav>

    <header id="header" class="container-fluid px-0" style="background-image:url('assets/background.jpeg');">
            <div class="text1">CUCIAN BANYAK ? <br> MALAS CUCI SENDIRI ?</div>     
            <div class="text2">CONTACT US</div>
            <div class="text3">Informasi lebih lanjut kalian bisa menghubungi kami di 0822 9966 258787 (Admin) atau email ke info@buihbersihlaundry.com. Kunjungi juga workshop kami di Jalan Sukapura 76 Kel. Sukapura - Kec. Dayeuhkolot Kab. Bandung 40267</div>
    </header>
    <h1 style="text-align: center; padding-top: 5%;">Buih Bersih Mempunyai 3 Layanan, yuk simak penjelasannya!</h1>
    
    <div class="container">
        <div class="slider">
            <img src="assets/slider1.png">
            <h1 style="text-align: center ; padding-top: 350px ">Laundry Express Sameday adalah layanan cepat hanya dengan 3-6 jam, jika kamu sedang membutuhkan waktu cepat untuk membersihkan pakaianmu!</h1>
            <img src="assets/slider2.png">
            <h1 style="text-align: center ; padding-top: 350px ">Laundry Kiloan Reguler adalah layanan reguler dengan harga ekonomis! Laundry kamu selesai dalam waktu 3-4 hari.</h1>
            <img src="assets/slider3.png">
            <h1 style="text-align: center ; padding-top: 350px ">Laundry Satuan ini tidak hanya pakaian saja, tetapi bisa mencuci karpet, Selimut, Sprei, Boneka dan barang lainnya yang mempunyai bahan kain!</h1>
        </div>
    </div>


    <div class="container">
        <div class="row" style="padding-bottom:2rem">
            <div class="col-8">
                <h1 style="padding-top:150px ;">LAYANAN</h1>
                <p>Halaman ini hanya dapat melihat daftar harga dan jenis layanan!</p>
            </div>
            <div class="col-4">
                <img style="height: 300px ;" src="assets/jenispelayanan.png" alt="">
            </div>
        </div>

          <table id="example" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>Estimasi waktu</th>
                    <th>Tarif</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Express</td>
                    <td>3-6 jam</td>
                    <td>Rp.8000 / kg</td>

                </tr>
                <tr>
                    <td>Reguler</td>
                    <td>2-3 hari</td>
                    <td>Rp.5000 / kg</td>
                </tr>
                <tr>
                    <td>Satuan pakaian (Tipis)</td>
                    <td>1-2 hari</td>
                    <td>Rp.2000 / satuan</td>
                </tr>
                <tr>
                    <td>Satuan pakaian (Tebal)</td>
                    <td>2-3 hari</td>
                    <td>Rp.4000 / satuan</td>
                </tr>
                <tr>
                    <td>Sprei (Set)</td>
                    <td>2-3 hari</td>
                    <td>Rp.6000 / set</td>
                </tr>
                <tr>
                    <td>Bed cover</td>
                    <td>2-4 hari</td>
                    <td>Rp.20.000 / satuan</td>
                </tr>
                <tr>
                    <td>Karpet (Tergantung ukuran)</td>
                    <td>4-6 hari</td>
                    <td>Rp.20.000 - 65.000 / satuan</td>
                </tr>
                </tbody>
                </table>
            </div>
    </div>

    <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2022 Copyright:
    <a class="text-reset fw-bold">Laundry</a>
  </div>
  <!-- Copyright -->

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

</body>

    <script>
        $(document).ready(function () { 
            $('#example').DataTable();
            $('.slider').bxSlider();
        });
    </script>
</html>